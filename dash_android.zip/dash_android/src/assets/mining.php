<?php include('config.php');?>
<?php include('db.php');?>

<!doctype html>
<html lang="en">
<?php include('header.php');?>

<body onload="countdown()" class="text-center" background="img/bg6.png">

               <form action = "<?php echo $_PHP_SELF ?>" id = "report">

      <script type="text/javascript">
      	var ss = 10000;
      	var add = 0;
      	function countdown(){
		 ss = ss - 1; 
		 
		 add = add + 0.0001;
		 if(ss<0){
		 	window.location = "mining.php";
		 }else{
		 	document.getElementById("countdown").innerHTML = ss;
		 	document.getElementById("add").innerHTML = add;
		 	window.setTimeout("countdown()", 1000);
		 }
		}
      </script>
       <h2 id="countdown" style="color: white"></h2>
	  <img class="mb-4" src="img/favicon.png" alt=""  width="150" height="150">
	  <br>	<b><input type="submit"  class="btn btn-success btn-lg" style="border-radius: 2em" value="Start mining"/></b>
	</form>
	
	<footer class="footer">
      <div class="container">
        <span class="text-muted">
  <?php
echo "<strong><font color='black' id = 'add'></font></strong>";  
include('api/api-call-tradeamount.php');

            ?>
			<?php include('footertext.php');?>
      </span></div>
    </footer> 
      
    	<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="js/jquery-slim.min.js"><\/script>')</script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	
  </body>
</html>
