  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="img/favicon.ico">

    <title>Dashcoin - Free crypto coin trade php script</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/form.css" rel="stylesheet">
	<link href="css/sticky-footer.css" rel="stylesheet">
	<link href="webfont/cryptocoins.css" rel="stylesheet">
  </head>