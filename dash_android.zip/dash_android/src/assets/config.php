 <?php
 $apiKey = ''; // Changelly API key
 $apiSecret = ''; // Changelly API secret
 $apiUrl = 'https://api.changelly.com'; // Don't change
 
 $pair = 'ltc'; // Lowercase only!
 $pairfullname = 'Litecoin'; // Coin full name
 $pairreceive = 'eth'; // Lowercase only!
 $pairreceivefullname = 'Ethereum';
 
 // Don't edit below this line
 $pairicon = strtoupper($pair);
 $pairreceiveicon = strtoupper($pairreceive);
 ?>