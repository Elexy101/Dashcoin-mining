package com.example.dash_mine;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TabHost;

public class MainActivity extends Activity {
TabHost host;
WebView web1, web2;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		host = (TabHost) findViewById(R.id.tabHost);
		host.setup();
		
		//tab 1
		TabHost.TabSpec spec = host.newTabSpec("Mining");
		spec.setContent(R.id.tab1);
		spec.setIndicator("Mining");
		host.addTab(spec);

		//tab 2
		spec = host.newTabSpec("Withdrawal");
		spec.setContent(R.id.tab2);
		spec.setIndicator("Withdrawal");
		host.addTab(spec);	
		
		//tab 2
		spec = host.newTabSpec("Send/Receive");
		spec.setContent(R.id.tab3);
		spec.setIndicator("Send/Receive");
		host.addTab(spec);
		
		if(spec.toString() == "Mining"){
			web1 = (WebView) findViewById(R.id.web1);
			web1.loadUrl("file:///android_asset/mining.html");
			web1.setWebViewClient(new WebViewClient());
			WebSettings webSettings = web1.getSettings();
			
			webSettings.setJavaScriptEnabled(true);
				
		}else{
			web1 = (WebView) findViewById(R.id.web1);
			web1.loadUrl("file:///android_asset/mining.html");
			web1.setWebViewClient(new WebViewClient());
			WebSettings webSettings = web1.getSettings();
			
			webSettings.setJavaScriptEnabled(true);
		}
		
		if(spec.toString() == "Withdrawal"){
			web2 = (WebView) findViewById(R.id.web2);
			web2.loadUrl("file:///android_asset/mining.html");
			web2.setWebViewClient(new WebViewClient());
			WebSettings webSettings = web2.getSettings();
			
			webSettings.setJavaScriptEnabled(true);
				
		}else{
			web2 = (WebView) findViewById(R.id.web2);
			web2.loadUrl("file:///android_asset/mining.html");
			web2.setWebViewClient(new WebViewClient());
			WebSettings webSettings = web2.getSettings();
			
			webSettings.setJavaScriptEnabled(true);
		}
	}
}
