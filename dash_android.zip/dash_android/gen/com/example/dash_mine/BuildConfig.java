/** Automatically generated file. DO NOT MODIFY */
package com.example.dash_mine;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}